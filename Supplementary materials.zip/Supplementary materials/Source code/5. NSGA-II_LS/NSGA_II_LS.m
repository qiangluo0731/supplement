function NSGA_II_LS()
%% Objectives��total earliness/tardiness penalty costs and total energy consumption

clc
clear
dbstop if error

% read benchmark
files=dir('*.mat');
for f=1:numel(files)
    filename=files(f).name;
    load(filename);
    job_num=job_set{1}(1);
    stage_num=job_set{1}(2);
    job_type=job_set{2};
    shop_num=manufacturer_set{2};
    inven_set=manufacturer_set{end};
    TPL_num=size(servicer_set{1},2);
    for j=1:job_num
        M_Cus_dis(j)=pdist([manufacturer_set{1}';job_set{3}(:,j)'],'euclidean');
    end
    for m=1:TPL_num
        M_TPL_dis(m)=pdist([manufacturer_set{1}';servicer_set{1}(:,m)'],'euclidean');
    end
    
    %% input
    pop_size=100;
    cro_rate=0.7;
    mut_rate=0.2;
    ls_num=10;
    time_stop=job_num/2;
    Obj_num=2;
    count=20;
    Population_child_all=[];
    for k=1:count
        tic;
        %% initialization
        pop_st=initial_pop_R(job_num,job_type,shop_num,inven_set,TPL_num,pop_size,manufacturer_set{3},stage_num);
        %% decoding
        Population=decode_pop(pop_st,job_num,stage_num,job_type,shop_num,pop_size,M_Cus_dis,M_TPL_dis,job_set{4},job_set{5},manufacturer_set,servicer_set);
        [~,FrontNo,CrowdDis] = EnvironmentalSelection(Population,pop_size,Obj_num);
        num=1;
        alpha=1;
        while toc<=time_stop
            %% evolutionary stage
            if mod(num,10)==1;
                EV=zeros(1,10);
            end
            MatingPool=TournamentSelection(2,pop_size/2,FrontNo,-CrowdDis);
            pop_first1=Population(FrontNo==1);
            cross_pop=crossPopulate(Population(MatingPool),pop_size/2,cro_rate,job_num,shop_num,inven_set,alpha);
            mut_pop=mutation_pop(cross_pop,pop_size,mut_rate,shop_num,job_num,job_type,inven_set,TPL_num);
            pop_evo=decode_pop(mut_pop,job_num,stage_num,job_type,shop_num,numel(mut_pop),M_Cus_dis,M_TPL_dis,job_set{4},job_set{5},manufacturer_set,servicer_set);
            Pop_home=[Population,pop_evo];
            [Population,FrontNo,CrowdDis] = EnvironmentalSelection(Pop_home,numel(Pop_home),Obj_num);
            col_set=find(FrontNo==1);
            ls_cur=min([length(col_set),ls_num]);
            [~,col_ls]=sort(CrowdDis(col_set),'descend');
            Pop_first=Population(col_set(col_ls(1:ls_cur)));
            New_better_ind=local_search(Pop_first,ls_cur,job_set{4},job_set{5},job_type,shop_num,job_num,stage_num,M_Cus_dis,M_TPL_dis,manufacturer_set,servicer_set);
            Population(col_set(col_ls(1:ls_cur)))=New_better_ind;
            %% Execute elite strategy to select the population for next iteration
            [Population,FrontNo,CrowdDis] = EnvironmentalSelection(Population,pop_size,Obj_num);
            pop_first2=Population(FrontNo==1);
            [C_value1]=compute_C(pop_first1,pop_first2,Obj_num);
            [C_value2]=compute_C(pop_first2,pop_first1,Obj_num);
            if C_value1>C_value2
                if mod(num,10)~=0
                    EV(mod(num,10))=1;
                else
                    EV(10)=1;
                end
            end
            if mod(num,10)==0
                if isempty(find(EV>0, 1))
                    alpha=1;
                elseif length(find(EV>0))>5
                    a=1;
                else
                    alpha=max([0.5,alpha-0.05]);
                end
            end
            num=num+1;
        end
        Population_child_all=[Population_child_all,pop_first2];
    end
    objs_set=reshape([Population_child_all.objectives],[Obj_num,numel(Population_child_all)])';
    [~,remain_set]=unique(objs_set,'rows');
    PF_final=Population_child_all(remain_set);
    [PF_final,FrontNo,~] = EnvironmentalSelection(PF_final,length(remain_set),Obj_num);
    Population_first=PF_final(FrontNo==1);
    PF_mean_value=round(mean((reshape([Population_first.objectives],Obj_num,size(Population_first,2)))'));
    filename_result=strcat('result_all_',num2str(f));
    save(filename_result,'Population_first','PF_mean_value');
end
end
