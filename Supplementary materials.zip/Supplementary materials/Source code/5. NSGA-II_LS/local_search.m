function Output_better_ind=local_search(pop,ls_num,due_time_set,penalty_set,job_type,shop_num,job_num,stage_num,M_Cus_dis,M_TPL_dis,manufacturer_set,servicer_set)

New_better_ind=pop(1);
Output_better_ind=pop;
for i=1:ls_num
    pop_one=pop(i);
    chrom=pop_one.chrom;
    decode_transport=pop_one.decode_transport;
    method_rank=randperm(4,1);
    if method_rank==1
        [~,loc_set]=sort(decode_transport(5,:),'descend');
        for j=1:3
            flag=0;
            job_rank_j=loc_set(j);
            job_type_j=job_type(job_rank_j);
            if decode_transport(4,job_rank_j)>due_time_set(2,j)
                delay_or_early=1;
                due_time_j=due_time_set(2,job_rank_j);
                due_time_candi=(due_time_set(2,:));
            else
                delay_or_early=0;
                due_time_j=due_time_set(1,job_rank_j);
                due_time_candi=(due_time_set(1,:));
            end
            
            if chrom(1,job_rank_j)<=shop_num
                [~,inv_loc]=find(chrom(1,:)==shop_num+job_type_j);
            else
                [~,inv_loc_1]=find(job_type==job_type_j);
                inv_loc=inv_loc_1(chrom(1,inv_loc_1)~=job_type_j+shop_num);
            end
            
            if delay_or_early
                [~,index]=find(due_time_candi(inv_loc)>due_time_j);
                [~,loc]=sort(due_time_candi(index),'descend');
                candi_jobs=inv_loc(index(loc));
            else
                [~,index]=find(due_time_candi(inv_loc)<due_time_j);
                [~,loc]=sort(due_time_candi(index));
                candi_jobs=inv_loc(index(loc));
            end
            
            for g=1:length(index)
                job_rank_g=candi_jobs(g);
                due_time_g=due_time_candi(1,candi_jobs(g));
                pre_total_tardi=sum(decode_transport(5,[job_rank_j,job_rank_g]));
                diff_value_g=due_time_g-decode_transport(4,job_rank_j);
                if diff_value_g>0
                    tardi_job_g=diff_value_g*penalty_set(1,job_rank_g);
                elseif diff_value_g<=0
                    tardi_job_g=abs(diff_value_g)*penalty_set(2,job_rank_g);
                end
                
                diff_value_j=due_time_j-decode_transport(4,job_rank_g);
                if diff_value_j>0
                    tardi_job_j=diff_value_j*penalty_set(1,job_rank_j);
                elseif diff_value_j<=0
                    tardi_job_j=abs(diff_value_j)*penalty_set(2,job_rank_j);
                end
                
                if  (tardi_job_j+tardi_job_g)<pre_total_tardi
                    % new solution is better than old one
                    chrom(1:2,[job_rank_j,job_rank_g])=chrom(1:2,[job_rank_g,job_rank_j]);
                    New_better_ind.chrom=chrom;
                    New_better_ind.need_decode=1;
                    New_better_ind=decode_pop(New_better_ind,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time_set,penalty_set,manufacturer_set,servicer_set);
                    if dominate(New_better_ind.objectives,Output_better_ind(i).objectives)
                        flag=1;
                        break
                    end
                end
            end
            if flag
                Output_better_ind(i)=New_better_ind;
                break;
            end
        end

    elseif method_rank==2
        [~,job_rank_set]=find(chrom(1,:)<=shop_num);
        loc_set=find(decode_transport(5,job_rank_set)>0);
        candi_set=loc_set(randperm(length(loc_set),min([length(loc_set),3])));
        early_delay_set=decode_transport(5,job_rank_set(candi_set));
        job_rank_j=job_rank_set(candi_set(early_delay_set==max(early_delay_set)));
        job_rank_j=job_rank_j(1);
        job_type_j=job_type(job_rank_j);
        inv_loc=find(job_type_j==job_type & chrom(1,:)<=shop_num);
        if decode_transport(4,job_rank_j)>due_time_set(2,job_rank_j)
            due_time_j=due_time_set(2,job_rank_j);
            due_time_candi=(due_time_set(2,inv_loc));
            [~,index]=find(due_time_candi>due_time_j);
            candi_jobs=inv_loc(index);
            candi_jobs=candi_jobs(1,chrom(2,job_rank_j)>chrom(2,candi_jobs));
            due_time_candi=due_time_set(1,candi_jobs(chrom(2,job_rank_j)>chrom(2,candi_jobs)));
        else
            due_time_j=due_time_set(1,job_rank_j);
            due_time_candi=(due_time_set(1,inv_loc));
            [~,index]=find(due_time_candi<due_time_j);
            candi_jobs=inv_loc(index);
            candi_jobs=candi_jobs(1,chrom(2,job_rank_j)<chrom(2,candi_jobs));
            due_time_candi=due_time_set(1,candi_jobs(chrom(2,job_rank_j)<chrom(2,candi_jobs)));
        end
        for g=1:length(candi_jobs)
            job_rank_g=candi_jobs(g);
            due_time_g=due_time_candi(1,g);
            pre_total_tardi=sum(decode_transport(5,[job_rank_j,job_rank_g]));
            diff_value_g=due_time_g-decode_transport(4,job_rank_j);
            if diff_value_g>0
                tardi_job_g=diff_value_g*penalty_set(1,job_rank_g);
            elseif diff_value_g<=0
                tardi_job_g=abs(diff_value_g)*penalty_set(2,job_rank_g);
            end
            
            diff_value_j=due_time_j-decode_transport(4,job_rank_g);
            if diff_value_j>0
                tardi_job_j=diff_value_j*penalty_set(1,job_rank_j);
            elseif diff_value_j<=0
                tardi_job_j=abs(diff_value_j)*penalty_set(2,job_rank_j);
            end
            
            if  (tardi_job_j+tardi_job_g)<pre_total_tardi
                % new solution is better than old one
                chrom(1:2,[job_rank_j,job_rank_g])=chrom(1:2,[job_rank_g,job_rank_j]);
                New_better_ind.chrom=chrom;
                New_better_ind.need_decode=1;
                New_better_ind=decode_pop(New_better_ind,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time_set,penalty_set,manufacturer_set,servicer_set);
                if dominate(New_better_ind.objectives,Output_better_ind(i).objectives)
                    Output_better_ind(i)=New_better_ind;
                    break
                end
            end
        end
        
    elseif method_rank==3
        [~,job_rank_set]=find(chrom(1,:)<=shop_num);
        loc_set=find(decode_transport(5,job_rank_set)>0);
        candi_set=loc_set(randperm(length(loc_set),min([length(loc_set),3])));
        early_delay_set=decode_transport(5,job_rank_set(candi_set));
        job_rank_j=job_rank_set(candi_set(early_delay_set==max(early_delay_set)));
        job_rank_j=job_rank_j(1);
        end_time_set=decode_transport(4,job_rank_set);
        end_time_set_copy=end_time_set;

        end_time_set_copy=end_time_set_copy-due_time_set(1,job_rank_j);
        job_remain_set=job_rank_set(end_time_set_copy>0);
        if isempty(job_remain_set)
            continue;
        end
        [~,loc_set]=sort(end_time_set_copy(end_time_set_copy>0));
        job_rank_g=job_remain_set(loc_set(1));
        for g=1:2
            if g==1
                chrom(1:2,job_rank_j)=[chrom(1,job_rank_g);chrom(2,job_rank_g)+0.0001];
                New_better_ind.chrom=chrom;
                New_better_ind.need_decode=1;
                New_better_ind=decode_pop(New_better_ind,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time_set,penalty_set,manufacturer_set,servicer_set);
                if dominate(New_better_ind.objectives,Output_better_ind(i).objectives)
                    Output_better_ind(i)=New_better_ind;
                    break
                end
            else
                chrom(1:2,job_rank_j)=[chrom(1,job_rank_g),chrom(2,job_rank_g)-0.0001];
                New_better_ind.chrom=chrom;
                New_better_ind.need_decode=1;
                New_better_ind=decode_pop(New_better_ind,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time_set,penalty_set,manufacturer_set,servicer_set);
                if dominate(New_better_ind.objectives,Output_better_ind(i).objectives)
                    Output_better_ind(i)=New_better_ind;
                end
            end
        end
        
    else
        speed_set=servicer_set{2};
        energy_set=servicer_set{3};
        for j=1:job_num
            veh_rank_j=chrom(3,j);
            energy_unload_j=energy_set(2,veh_rank_j);
            energy_load_j=energy_set(1,veh_rank_j);
            speed_unload_j=speed_set(1,veh_rank_j);
            speed_load_j=speed_set(2,veh_rank_j);
            trans_unload_energy=round(M_TPL_dis(veh_rank_j)/speed_unload_j)*energy_unload_j;
            trans_load_energy=round(M_Cus_dis(j)/speed_load_j)*energy_load_j;
            old_energy=round(trans_unload_energy+trans_load_energy);
            due_time_j_low=due_time_set(1,j);
            due_time_j_up=due_time_set(2,j);

            if decode_transport(4,j)<due_time_set(1,j) || decode_transport(5,j)==0
                col_set=find(energy_set(2,:)<energy_unload_j & energy_set(1,:)<energy_load_j);
                [~,index]=sort(energy_set(2,col_set));
                col_set=col_set(index);
                for v=1:length(col_set)
                    veh_rank_g=col_set(v);
                    trans_time_1=round(M_TPL_dis(veh_rank_g)/speed_set(1,veh_rank_g));
                    trans_time_2=round(M_Cus_dis(j)/speed_set(2,veh_rank_g));
                    ST=max([trans_time_1,decode_transport(2,j)]);
                    CT=ST+trans_time_2;
                    cost=0;
                    if CT<due_time_j_low  % early
                        cost=(due_time_j_low-CT)*penalty_set(1,j);
                    elseif CT>due_time_j_up  % delay
                        cost=(CT-due_time_j_up)*penalty_set(2,j);
                    end
                    if decode_transport(5,j)>cost || cost==0
                        energy_unload_g=energy_set(2,veh_rank_g);
                        energy_load_g=energy_set(1,veh_rank_g);
                        new_energy=energy_unload_g*trans_time_1+energy_load_g*trans_time_2;
                        if old_energy>new_energy
                            chrom(3,j)=veh_rank_g;
                            break;
                        end
                    end
                end
            end
        end
        New_better_ind.chrom=chrom;
        New_better_ind.need_decode=1;
        Output_better_ind(i)=decode_pop(New_better_ind,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time_set,penalty_set,manufacturer_set,servicer_set);
    end
end
end
