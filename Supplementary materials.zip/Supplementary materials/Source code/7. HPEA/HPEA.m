function HPEA
% self-adaptive multi-objective evolutionary algorithm based on
% decomposition (HPEA)

%------------------------------- Reference --------------------------------
% Li, R., Gong, W. Y., & Lu, C. (2022). Self-adaptive multi-objective
% evolutionary algorithm for flexible job shop scheduling with fuzzy
% processing time. Computers & Industrial Engineering, 168. doi: ARTN
% 10809910.1016/j.cie.2022.108099
%--------------------------------------------------------------------------

%% Objectives��total earliness/tardiness penalty costs and total energy consumption

clc
clear
dbstop if error
global reference_point;

% read benchmark
files=dir('*.mat');
for f=1:numel(files)
    filename=files(f).name;
    load(filename);
    job_num=job_set{1}(1);
    stage_num=job_set{1}(2);
    job_type=job_set{2};
    shop_num=manufacturer_set{2};
    inven_set=manufacturer_set{end};
    TPL_num=size(servicer_set{1},2);
    for j=1:job_num
        M_Cus_dis(j)=pdist([manufacturer_set{1}';job_set{3}(:,j)'],'euclidean');
    end
    for m=1:TPL_num
        M_TPL_dis(m)=pdist([manufacturer_set{1}';servicer_set{1}(:,m)'],'euclidean');
    end
    
    %% input
    PS=100;
    T=[4,6,8,10];
    MR=0.1;
    LP = 40;
    time_stop=job_num/2;
    Obj_num=2;
    runTime=20;
    T_size=length(T);
    Population_child_all=[];
    for m=1:runTime
        tic;
        %% initialization
        pop_st=initial_pop_R(job_num,job_type,shop_num,inven_set,TPL_num,PS,manufacturer_set{3},stage_num);
        %% decoding
        Population=decode_pop(pop_st,job_num,stage_num,job_type,shop_num,PS,M_Cus_dis,M_TPL_dis,job_set{4},job_set{5},manufacturer_set,servicer_set);
        [weights,neighbour]=init_weight(PS+1,2,T(T_size));
        obj=reshape([Population.objectives],Obj_num,PS)';
        reference_point=min(obj);
        numst=T_size;
        %Record the number of success or failure
        ns =[];
        nf = [];
        %Record the success rate
        pfit = ones(1, numst);
        iter_rank=0;
        while toc<=time_stop
            % Stochastic universal sampling
            rr = rand;
            spacing = 1/PS;
            randnums = sort(mod(rr : spacing : 1 + rr - 0.5 * spacing, 1));
            
            sumfit=0;
            for j=1:numst
                sumfit=pfit(j)+sumfit;
            end
            for j=1:numst
                normfit(j)=pfit(j)/sumfit;
            end
            partsum = 0;
            count(1) = 0;
            stpool = [];
            
            for j = 1 : length(pfit)
                partsum = partsum + normfit(j);
                count(j + 1) = length(find(randnums < partsum));
                select(j, 1) = count(j + 1) - count(j);
                stpool = [stpool; ones(select(j, 1), 1) * j];
            end
            stpool = stpool(randperm(PS));
            scount=zeros(1,numst);
            lcount=zeros(1,numst);
            %MOEAD
            for j=1:PS
                chooseT=T(stpool(j));
                nei=neighbour(j,:);
                nb1=nei(ceil(rand*chooseT));
                nb2=nei(ceil(rand*chooseT));
                while nb1==nb2
                    nb2=nei(ceil(rand*chooseT));
                end
                cross_pop=crossPopulate(Population(nb1),Population(nb2),job_num,shop_num,inven_set);
                mut_pop=mutation_pop(cross_pop,numel(cross_pop),shop_num,job_num,job_type,inven_set,TPL_num,MR);
                pop_evo=decode_pop(mut_pop,job_num,stage_num,job_type,shop_num,numel(mut_pop),M_Cus_dis,M_TPL_dis,job_set{4},job_set{5},manufacturer_set,servicer_set);
                new_obj=reshape([pop_evo.objectives],Obj_num,numel(pop_evo))';
                reference_point=min([reference_point;new_obj]);
                for t=1:chooseT
                    k=nei(t);
                    flag=updates(weights(k,:),pop_evo(1),Population(k));
                    if flag==1
                        Population(k)=pop_evo(1);
                        scount(stpool(j))=scount(stpool(j))+1;
                    else
                        lcount(stpool(j))=lcount(stpool(j))+1;
                    end
                end
                
                for t=1:chooseT
                    k=nei(t);
                    flag=updates(weights(k,:),pop_evo(2),Population(k));
                    if flag==1
                        Population(k)=pop_evo(2);
                        scount(stpool(j))=scount(stpool(j))+1;
                    else
                        lcount(stpool(j))=lcount(stpool(j))+1;
                    end
                end
                % local search
                new_ind=local_search(Population(j),1,job_set{4},job_set{5},job_type,shop_num,job_num,stage_num,M_Cus_dis,M_TPL_dis,manufacturer_set,servicer_set);
                Population(j)=new_ind;
            end
            
            ns=[ns;scount];
            nf=[nf;lcount];
            iter_rank=iter_rank+1;
            if iter_rank >= LP
                for j = 1 : numst
                    sum_ns=sum(ns(:,j));
                    sum_nf=sum(nf(:,j));
                    if (sum_ns + sum_nf) == 0
                        pfit(j) = 0.01;
                    else
                        pfit(j) = sum_ns / (sum_ns + sum_nf) + 0.01;
                    end
                end
                if ~isempty(ns), ns(1, :) = [];  end
                if ~isempty(nf), nf(1, :) = [];  end
            end
        end
        Population_child_all=[Population_child_all,Population];
    end
    objs_set=reshape([Population_child_all.objectives],[Obj_num,numel(Population_child_all)])';
    [~,remain_set]=unique(objs_set,'rows');
    Population_sorted=non_dominant_sort(Population_child_all(remain_set),numel(Population_child_all(remain_set)),Obj_num);
    Population_first=Population_sorted([Population_sorted.rank]==1);
    PF_mean_value=round(mean((reshape([Population_first.objectives],Obj_num,size(Population_first,2)))'));
    filename_result=strcat('result_all_',num2str(f));
    save(filename_result,'Population_first','PF_mean_value');
end
end
