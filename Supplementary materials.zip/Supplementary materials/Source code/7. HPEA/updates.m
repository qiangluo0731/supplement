function flag=updates(weight,pop_new,pop_old)
global reference_point;
flag=0;
part=abs(pop_new.objectives-reference_point);
newobj=max(weight.*part);
part=abs(pop_old.objectives-reference_point);
oldobj=max(weight.*part);
if newobj<oldobj
    flag=1;
end
end