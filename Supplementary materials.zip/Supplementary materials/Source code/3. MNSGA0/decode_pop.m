function [pop_st]=decode_pop(pop_st,job_num,stage_num,job_type,shop_num,pop_size,M_Cus_dis,M_TPL_dis,due_time,penalty_set,manufacturer_set,servicer_set)

for ind=1:pop_size
    if pop_st(ind).need_decode
        decode_shop=cell(1,shop_num);
        chrom_set=pop_st(ind).chrom;
        pro_ending_time=zeros(1,job_num);
        pro_energy=[];
        idle_energy=[];
        %% decode the production stage in each shop
        for sh=1:shop_num
            protime_set=manufacturer_set{3}{1,sh};
            mach_energy_set=manufacturer_set{4}{1,sh};
            [~,job_set_temp]=find(chrom_set(1,:)==sh);
            [~,index]=sort(chrom_set(2,job_set_temp));
            for j=1:length(index)
                CT_pre_mach=0;
                CT_pre_stage=0;
                job_rank=job_set_temp(index(j));
                for s=1:stage_num
                    if s>1
                        CT_pre_stage=decode_shop{sh}(j,2*(s-1));
                    end
                    if j>1
                        CT_pre_mach=decode_shop{sh}(j-1,2*s);
                    end
                    ST_now=max(CT_pre_stage,CT_pre_mach);
                    decode_shop{sh}(j,2*s-1:2*s)=[ST_now,ST_now+protime_set(job_type(job_rank),s)];
                    pro_energy=[pro_energy,mach_energy_set(1,s)*protime_set(job_type(job_rank),s)];
                    idle_time=ST_now-CT_pre_mach;
                    idle_energy=[idle_energy,mach_energy_set(2,s)*idle_time];
                end
            end
            decode_shop{sh}=[job_set_temp(index)',decode_shop{sh}];
            pro_ending_time(job_set_temp(index))=decode_shop{sh}(:,end)';
        end
        production_energy=sum(pro_energy)+sum(idle_energy);
        
        [decode_trans,trans_energy]=decode_distribution(servicer_set,chrom_set,pro_ending_time,job_num,M_TPL_dis,M_Cus_dis);
        
        %% calculate two objectives: total earliness/tardiness costs & total energy consumption
        TEC=round(production_energy+trans_energy);
        for i=1:job_num
            if decode_trans(4,i)<due_time(1,i)  % early
                early_cost=(due_time(1,i)-decode_trans(4,i))*penalty_set(1,i);
                decode_trans(5,i)=round(early_cost);
            elseif decode_trans(4,i)>due_time(2,i)  % delay
                delay_cost=(decode_trans(4,i)-due_time(2,i))*penalty_set(2,i);
                decode_trans(5,i)=round(delay_cost);
            end
        end
        TC=sum(decode_trans(5,:));
        pop_st(ind).decode_shop=decode_shop;
        pop_st(ind).decode_transport=decode_trans;
        pop_st(ind).objectives=[TC,TEC];
        pop_st(ind).need_decode=0;
    end
end
end


function [decode_trans,trans_energy]=decode_distribution(servicer_set,chrom_set,pro_ending_time,job_num,M_TPL_dis,M_Cus_dis)

%% decode the transportation stage based on the completion time of jobs
speed_set=servicer_set{2};
energy_set=servicer_set{3};
decode_trans=[chrom_set(3,:);pro_ending_time];
trans_unload_energy=zeros(1,job_num);
trans_load_energy=trans_unload_energy;
used_time=cell(1,size(servicer_set{1},2));
[~,trans_seq]=sort(pro_ending_time,'ascend');
for t=1:length(trans_seq)
    job_rank=trans_seq(t);
    ts_rank=chrom_set(3,job_rank);
    if isempty(used_time{ts_rank})
        trans_time_1=round(M_TPL_dis(ts_rank)/speed_set(1,ts_rank));
        decode_trans(3,job_rank)=max([trans_time_1,pro_ending_time(job_rank)]);
        trans_time_2=round(M_Cus_dis(job_rank)/speed_set(2,ts_rank));
        decode_trans(4,job_rank)=decode_trans(3,job_rank)+trans_time_2;
    else
        vei_ST=max(used_time{ts_rank}(:,2));
        last_job=used_time{ts_rank}(end,3);
        trans_time_1=round(M_Cus_dis(last_job)/speed_set(1,ts_rank));
        decode_trans(3,job_rank)=max([trans_time_1+vei_ST,pro_ending_time(job_rank)]);
        trans_time_2=round(M_Cus_dis(job_rank)/speed_set(2,ts_rank));
        decode_trans(4,job_rank)=decode_trans(3,job_rank)+trans_time_2;
    end
    trans_unload_energy(job_rank)=trans_time_1*energy_set(2,ts_rank);
    trans_load_energy(job_rank)=trans_time_2*energy_set(1,ts_rank);
    used_time{ts_rank}=[used_time{ts_rank};[decode_trans(3,job_rank)-trans_time_1,decode_trans(3,job_rank)+trans_time_2,job_rank]];
end
trans_energy=sum(trans_unload_energy)+sum(trans_load_energy);
end
