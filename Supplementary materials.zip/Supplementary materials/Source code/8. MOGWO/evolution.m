function Child=evolution(Population,cro_rate,mut_rate,FrontNo,CrowdDis,shop_num,job_num,job_type,inven_set,TPL_num)
P_mat=[];
P_off=[];
% crossover
while numel(P_mat)<numel(Population)*cro_rate
    P_rand=randperm(numel(Population),2);
    if FrontNo(P_rand(1))==FrontNo(P_rand(2))
        [~,id]=max(CrowdDis(P_rand));
    else
        [~,id]=min(FrontNo(P_rand));
    end
    P_mat=[P_mat,Population(id)];
end
for j=1:numel(P_mat)/2
    pos=randperm(numel(P_mat),2);
    Pa1=P_mat(pos(1));
    Pa2=P_mat(pos(2));
    P_mat(pos)=[];
    cross_pop=crossPopulate(Pa1,Pa2,job_num,shop_num,inven_set);
    P_off=[P_off,cross_pop];
end
% mutation
Child=mutation_pop(P_off,numel(P_off),mut_rate,shop_num,job_num,job_type,inven_set,TPL_num);
end
