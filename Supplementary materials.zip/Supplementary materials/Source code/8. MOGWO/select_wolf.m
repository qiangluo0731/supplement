function Child=select_wolf(Population,FrontNo,CrowdDis,Obj_num,pop_size,mu,job_num,stage_num,job_type,shop_num,M_Cus_dis,M_TPL_dis,due_time,penalty_set,manufacturer_set,servicer_set)

% determine wolves alpha,beta,deta
PF1_set=Population(FrontNo==1);
if numel(PF1_set)==1
    alpha=PF1_set;
    PF2_set=Population(FrontNo==2);
    if numel(PF2_set)==1
        beta=PF2_set;
        PF3_set=Population(FrontNo==3);
        dist_set=CrowdDis(FrontNo==3);
        [~,id]=find(max(dist_set)==dist_set);
        deta=PF3_set(id(randperm(length(id),1)));
    else
        dist_set=CrowdDis(FrontNo==2);
        [~,id]=sort(dist_set,'descend');
        beta=PF2_set(id(1));deta=PF2_set(id(2));
    end
elseif numel(PF1_set)==2
    alpha=PF1_set(1);
    beta=PF1_set(2);
    PF2_set=Population(FrontNo==2);
    dist_set=CrowdDis(FrontNo==2);
    [~,id]=find(max(dist_set)==dist_set);
    deta=PF2_set(id(randperm(length(id),1)));
else
    dist_set=CrowdDis(FrontNo==1);
    [~,id]=sort(dist_set,'descend');
    alpha=PF1_set(id(1));beta=PF1_set(id(2));deta=PF1_set(id(3));
end

% determine wolves omega1,omega2,omega3
obj_set=reshape([Population.objectives],Obj_num,pop_size)';
[id1,~]=find(min(obj_set(:,1))==obj_set(:,1));
[id2,~]=find(min(obj_set(:,2))==obj_set(:,2));
cd1=CrowdDis(id1);
[~,pos1]=min(cd1);
omega1=Population(pos1);
cd2=CrowdDis(id2);
[~,pos2]=min(cd2);
omega2=Population(pos2);
[~,pos_set]=find(max(FrontNo)==FrontNo);
cd3=CrowdDis(pos_set);
[~,pos2]=find(min(cd3)==cd3);
omega3=Population(pos_set(pos2(randperm(length(pos2),1))));

Child=gen_new_child_1(Population,alpha,beta,deta,omega1,omega2,omega3,mu,job_num,stage_num,job_type,shop_num,M_Cus_dis,M_TPL_dis,due_time,penalty_set,manufacturer_set,servicer_set);
end


function Population=gen_new_child_1(Population,alpha,beta,deta,omega1,omega2,omega3,mu,job_num,stage_num,job_type,shop_num,M_Cus_dis,M_TPL_dis,due_time,penalty_set,manufacturer_set,servicer_set)
X_best=(alpha.chrom(2,:)+beta.chrom(2,:)+deta.chrom(2,:))/3;
X_wrost=(omega1.chrom(2,:)+omega2.chrom(2,:)+omega3.chrom(2,:))/3;
for i=1:numel(Population)
    solution_new=Population(i);
    r1=rand;r2=rand;
    X_cur=Population(i).chrom(2,:);
    X_new=X_cur+mu*(r1*(X_best-X_cur)+r2*(X_cur-X_wrost));
    solution_new.chrom(2,:)=X_new;
    solution_new.need_decode=1;
    solution_new=decode_pop(solution_new,job_num,stage_num,job_type,shop_num,1,M_Cus_dis,M_TPL_dis,due_time,penalty_set,manufacturer_set,servicer_set);
    if dominate(solution_new.objectives,Population(i).objectives)
        Population(i)=solution_new;
    end
end
end
