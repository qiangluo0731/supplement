function [Population_ns]=non_dominant_sort(Population_decode,pop_size,m)

Population_ns=Population_decode;
rank=1;
person(1:pop_size)=struct('n',0,'s',[]);
F(rank).f=[];
I=1:pop_size;
for i=1:pop_size
    object_i=Population_decode(i).objectives(1:m);
    I(1:i)=[];
    if ~isempty(I)
        for jj=1:length(I)
            j=I(jj);
            object_j=Population_decode(j).objectives(1:m);
            log_num_i=dominate(object_i,object_j);
            log_num_j=dominate(object_j,object_i); 
            if log_num_i==1
                person(i).s=[person(i).s,j];
                person(j).n=person(j).n+1;
            end
            if log_num_j==1
                person(j).s=[person(j).s,i];
                person(i).n=person(i).n+1;
            end
        end
    end
    I=1:pop_size;
end
[~,col]=find([person.n]==0);
F(rank).f=col;

while ~isempty(F(rank).f)
    Q=[];
    for i=1:length(F(rank).f)
        if ~isempty(person(F(rank).f(i)).s)
            for j=1:length(person(F(rank).f(i)).s)
                person(person(F(rank).f(i)).s(j)).n=person(person(F(rank).f(i)).s(j)).n-1;
                if person(person(F(rank).f(i)).s(j)).n==0
                    Q=[Q,person(F(rank).f(i)).s(j)];
                end
            end
        end
    end
    rank=rank+1;
    F(rank).f=Q;
end
for ii=1:rank
    if ~isempty(F(ii).f)
        [~,col]=size(F(ii).f);
        for jj=1:col
            Population_ns(F(ii).f(jj)).rank=ii;
        end
    end    
end
[~,index]=sort([Population_ns.rank]);
Population_ns=Population_ns(index);
end
