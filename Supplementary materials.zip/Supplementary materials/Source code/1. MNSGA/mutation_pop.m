function pop_output=mutation_pop(cross_pop,pop_size,mut_rate,shop_num,job_num,job_type,inven_set,TPL_num)

pop_output=cross_pop;
veh_set=1:TPL_num;
for ind=1:pop_size
    if rand<mut_rate
        chrom=pop_output(ind).chrom;
        % Mutation on MS layer: alter supplication model (Method 1)
        % Or alter the production line (Method 2)
        method_rank=randperm(4,1);
        if method_rank==1
            % execute Method 1
            rand_pos=randperm(job_num,1);
            job_type_rank=job_type(rand_pos);
            if inven_set(job_type_rank)>0
                candi_set=find(chrom(1,:)==(shop_num+job_type_rank));
                swap_pos=candi_set(randperm(length(candi_set),1));
                chrom(1,[rand_pos,swap_pos])=flip(chrom(1,[rand_pos,swap_pos]));
            end
        elseif method_rank==2
            % execute Method 2
            mark=1;
            while mark==1
                rand_pos=randperm(job_num,1);
                sup_mode_now=chrom(1,rand_pos);
                if sup_mode_now<=shop_num
                    shop_set=1:shop_num;
                    shop_set(sup_mode_now)=[];
                    chrom(1,rand_pos)=shop_set(randperm(length(shop_set),1));
                    mark=0;
                end
            end
        elseif method_rank==3
            % Mutation on OS layer: re-generate a random value for a job in production
            prod_loc=find(chrom(1,:)<=shop_num);
            pos_rank=prod_loc(randperm(length(prod_loc),1));
            chrom(2,pos_rank)=rand;
        elseif method_rank==4
            % Mutation on TS layer: re-generate a servicer for a job
            pos_rank=randperm(job_num,1);
            temp_set=find(veh_set~=chrom(3,pos_rank));
            new_TPL=veh_set(temp_set(randperm(TPL_num-1,1)));
            chrom(3,pos_rank)=new_TPL;
        end
        pop_output(ind).chrom=chrom;
        pop_output(ind).need_decode=1;
    end
end
end
