function dominated_num_H=compute_C(pop1,pop2,Obj_num)

Population_child_all_H=reshape([pop1.objectives],Obj_num,numel(pop1))';
Population_child_all_I=reshape([pop2.objectives],Obj_num,numel(pop2))';

size_H = size(Population_child_all_H,1);
size_I = size(Population_child_all_I,1);
count_H=zeros(1,size_H);
for j=1:size_H
    obj_H=repmat(Population_child_all_H(j,:),size_I,1);
    islarge=obj_H-Population_child_all_I;
    islarge(islarge<0)=-1;
    islarge(islarge==0)=0;
    islarge(islarge>0)=1;
    count1=sum(islarge,2);
    if sum(count1)>0
        count_H(j)=1;
    end
end
dominated_num_H=sum(count_H)/size_H;
end
