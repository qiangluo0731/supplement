function pop_st=initial_pop_R(job_num,job_type,shop_num,inven_set,TPL_num,pop_size,pro_time_set,stage_num)
%% adpot a random intialization operator

pop_st=struct('chrom',[],'decode_shop',[],'decode_transport',[],'objectives',[],'need_decode',0);
for k=1:pop_size
    MS_vector=zeros(1,job_num);
    % generate a random production sequence
    OS_vector=rand(1,job_num);
    % usage of existing inventory of jobs
    for f=1:length(inven_set)
        if inven_set(f)~=0
            [~,type_i_loc]=find(job_type==f);
            type_i_num=length(type_i_loc);
            if type_i_num<=inven_set(f)
                MS_vector(type_i_loc)=shop_num+f;
            else
                inv_loc=type_i_loc(randperm(type_i_num,inven_set(f)));
                MS_vector(inv_loc)=shop_num+f;
            end
        end
    end
    [~,remaining_jobs]=find(MS_vector==0);
    % using NR2 hueristics
    remain_jobs_os=OS_vector(remaining_jobs);
    [~,col]=sort(remain_jobs_os);
    arranged_job=cell(shop_num,stage_num);
    for i=1:length(remaining_jobs)
        job_rank=remaining_jobs(col(i));
        type_rank=job_type(job_rank);
        [arranged_job,shop_rank]=NR2_method(shop_num,type_rank,arranged_job,pro_time_set{1},stage_num);
        MS_vector(job_rank)=shop_rank;
    end
    % select a 3PL provider for each job in a random order
    VS_vector=randi(TPL_num,[1,job_num]);
    pop_st(k).chrom=[MS_vector;OS_vector;VS_vector];
    pop_st(k).need_decode=1;
end
end

function [arranged_job_copy,shop_rank]=NR2_method(shop_num,type_rank,arranged_job,pro_time_v,stage_num)
% ���ް��ŵ��޼ӹ�����Ĺ���
% ������й���������㰲�ŵ�������ĳ���ʱ�䣬ѡ����������ķ���
arranged_job_copy=arranged_job;
makespan_i_shop=zeros(1,shop_num);
for sh=1:shop_num
    for s=1:stage_num
        if s==1
            if isempty(arranged_job{sh,s})
                CT_pre=0;
                CT_now=pro_time_v(type_rank,s);
                arranged_job{sh,s}=[CT_pre;CT_now];
            else
                CT_pre=arranged_job{sh,s}(2,end);
                CT_now=CT_pre+pro_time_v(type_rank,s);
                arranged_job{sh,s}=[arranged_job{sh,s},[CT_pre;CT_now]];
            end
        else
            % �����ϵ��������ʱ��Լ������ǰ�����ӹ�ʱ��Լ��
            if isempty(arranged_job{sh,s})
                CT_pre=arranged_job{sh,s-1}(2,end);
                CT_now=CT_pre+pro_time_v(type_rank,s);
                arranged_job{sh,s}=[CT_pre;CT_now];
            else
                CT_pre=max([arranged_job{sh,s-1}(2,end),arranged_job{sh,s}(2,end)]);
                CT_now=CT_pre+pro_time_v(type_rank,s);
                arranged_job{sh,s}=[arranged_job{sh,s},[CT_pre;CT_now]];
            end
        end
    end
    if s==stage_num
        makespan_i_shop(sh)=arranged_job{sh,s}(2,end);
    end
end
% ȷ�������깤�ķ���
col=find(min(makespan_i_shop)==makespan_i_shop);
shop_rank=col(1);
arranged_job_copy(shop_rank,:)=arranged_job(shop_rank,:);
end
