function c=dominate(a,b)
c=all(a<=b)&&any(a<b);
end