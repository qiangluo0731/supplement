function pop_output=crossPopulate(pop_parent,N,cro_rate,job_num,shop_num,inven_set,alpha)

pop_output=[];
for n=1:N
    candi_set=randperm(N,2);
    pop1=pop_parent(candi_set(1));
    pop2=pop_parent(candi_set(2));
    if rand<cro_rate
        chrom1=pop1.chrom;
        chrom2=pop2.chrom;
        
        % MS layer crossover based on binary array, and then execute rectification
        OS1=chrom1(1,:);
        OS2=chrom2(1,:);
        bi_array1=round(rand(1,job_num)*alpha);
        [~,loc1]=find(bi_array1==1);
        chrom_copy1=OS1(loc1);
        OS1(loc1)=OS2(loc1);
        OS2(loc1)=chrom_copy1;
        % rectification
        temp_vec=[OS1;OS2;bi_array1];
        rec_cro_points=[];
        for ind=1:2
            for v=1:length(inven_set)
                if length(find(temp_vec(ind,:)==shop_num+v))>inven_set(v)
                    % add additional crossover on MS to avoid infeasible offspring
                    loc=find(temp_vec(ind,:)==shop_num+v);
                    point_num=length(loc)-inven_set(v);
                    candi_loc=loc(temp_vec(3,loc)==0);
                    candi_loc=candi_loc(randperm(length(candi_loc),length(candi_loc)));
                    rec_cro_points_temp=[];
                    for j=1:length(candi_loc)
                        if temp_vec(1,candi_loc(j))~=temp_vec(2,candi_loc(j))
                            rec_cro_points_temp=[rec_cro_points_temp,candi_loc(j)];
                        end
                        if length(rec_cro_points_temp)==point_num
                            break;
                        end
                    end
                    rec_cro_points=[rec_cro_points,rec_cro_points_temp];
                end
            end
        end
        temp_value=temp_vec(1,rec_cro_points);
        temp_vec(1,rec_cro_points)=temp_vec(2,rec_cro_points);
        temp_vec(2,rec_cro_points)=temp_value;
        chrom1(1,:)=temp_vec(1,:);
        chrom2(1,:)=temp_vec(2,:);
        
        % OS and TS layers crossover based on binary array
        bi_array2=round(rand(1,job_num)*alpha);
        [~,loc2]=find(bi_array2==1);
        chrom_copy=chrom1(2,loc2);
        chrom1(2,loc2)=chrom2(2,loc2);
        chrom2(2,loc2)=chrom_copy;
        
        bi_array3=round(rand(1,job_num)*alpha);
        [~,loc3]=find(bi_array3==1);
        chrom_copy=chrom1(3,loc3);
        chrom1(3,loc3)=chrom2(3,loc3);
        chrom2(3,loc3)=chrom_copy;
        
        pop1.chrom=chrom1;
        pop2.chrom=chrom2;
        pop1.need_decode=1;
        pop2.need_decode=1;
        pop_output=[pop_output,pop1,pop2];
    else
        pop_output=[pop_output,pop1,pop2];
    end
end
end
